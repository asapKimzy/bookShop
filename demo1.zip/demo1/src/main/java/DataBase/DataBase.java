package DataBase;

import Model.Book;
import Model.Genre;
import Model.User;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;

public class DataBase {
    public static void main(String[] args) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {

//Genre genre= Genre.valueOf("WAR");
     //   System.out.println(genre);

//addBook(book);
//bookOut().stream().forEach(x-> System.out.println(x));
getId("5");
personalBook("6").stream().forEach(x-> System.out.println(x));




    }

    public static Connection getConnection() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        String url = "jdbc:mysql://localhost/bookshop";
        Class.forName ("com.mysql.cj.jdbc.Driver").newInstance ();
        Connection conn = DriverManager.getConnection (url, "root", "Rw-bmk197236");
        return conn;
    }
    public static void addUser(User user) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
    Connection connection=getConnection();
    PreparedStatement preparedStatement=connection.prepareStatement("insert into users(login, password, gender, country,role) values(?,?,?,?,?)");
    preparedStatement.setString(1, user.getLogin());
    preparedStatement.setString(2, user.getPassword());
    preparedStatement.setString(3, user.getGender());
    preparedStatement.setString(4, user.getCountry());
    preparedStatement.setString(5,"user");
    preparedStatement.executeUpdate();
    }
    public static Boolean checkLogin(String login) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
      Connection connection=getConnection();
      PreparedStatement preparedStatement=connection.prepareStatement("select * from users where login=?");
      preparedStatement.setString(1,login);
      ResultSet resultSet=preparedStatement.executeQuery();
      int count=0;
      while (resultSet.next()){
          User user= new User();
          user.setId(resultSet.getInt(1));
          user.setLogin(resultSet.getString(2));
          user.setPassword(resultSet.getString(3));
          user.setGender(resultSet.getString(4));
          user.setCountry(resultSet.getString(5));
          count++;

      }
      if(count!=0){
          return false;
      }
      return true;
    }
    public static Boolean authorisation(String login, String password) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Connection connection=getConnection();
        PreparedStatement preparedStatement=connection.prepareStatement("select count(*) from users where login=? and password=?");
        preparedStatement.setString(1,login);
        preparedStatement.setString(2,password);
        ResultSet resultSet=preparedStatement.executeQuery();
        int count=0;
        while (resultSet.next()){
            count= resultSet.getInt(1);
        }
        if(count!=0){
            return true;
        }
       return false;
    }
    public static void addBook(Book book) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Connection connection=getConnection();
      PreparedStatement preparedStatement= connection.prepareStatement("insert into books(name, num, price, author, genre) values(?,?,?,?,?)");
      preparedStatement.setString(1, book.getName());
      preparedStatement.setInt(2, book.getNum());
      preparedStatement.setBigDecimal(3,book.getPrice());
      preparedStatement.setString(4, book.getAuthor());
      preparedStatement.setString(5,book.getGenre().name());
      preparedStatement.executeUpdate();
    }
    public static ArrayList<Book> bookOut() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        ArrayList<Book> bookList=new ArrayList<>();
        Connection connection=getConnection();
        PreparedStatement preparedStatement=connection.prepareStatement("select * from books");
        ResultSet resultSet=preparedStatement.executeQuery();
        while (resultSet.next()){
            int id=resultSet.getInt(1);
            String name=resultSet.getString(2);
            int num=resultSet.getInt(3);
            BigDecimal price=resultSet.getBigDecimal(4);
            String author=resultSet.getString(5);
            String genre=resultSet.getString(6);
           Book book=new Book();
           book.setId(id);
           book.setName(name);
           book.setNum(num);
           book.setPrice(price);
           book.setAuthor(author);
           book.setGenre(Genre.valueOf(genre));
           bookList.add(book);
        }
return bookList;

    }
    public static String getRole(String login,String password) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Connection connection=getConnection();
        PreparedStatement preparedStatement=connection.prepareStatement("select role from users where login=? and password=?");
        preparedStatement.setString(1,login);
        preparedStatement.setString(2,password);
        ResultSet resultSet= preparedStatement.executeQuery();
        String role="";
        while (resultSet.next()) {
             role = resultSet.getString(1);
        }
        return role;
    }
    public static Boolean getId(String text) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Connection connection = getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement("select * from books where id=?");
        preparedStatement.setString(1, text);
        ResultSet resultSet = preparedStatement.executeQuery();
        int id = 0;
        while (resultSet.next()) {
            id = resultSet.getInt(1);
        }
        if (id != 0) {

            return true;
        } else
            return false;
    }
    public static void deleteBookFromUser(String id) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Connection connection=getConnection();
        PreparedStatement preparedStatement=getConnection().prepareStatement("update books set num=num-1 where id=?");
        preparedStatement.setString(1,id);
        preparedStatement.executeUpdate();
    }
    public static void addNumId(String id,int num) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Connection connection=getConnection();
        PreparedStatement preparedStatement=getConnection().prepareStatement("update books set num=num+? where id=?");
        preparedStatement.setInt(1,num);
        preparedStatement.setString(2,id);
        preparedStatement.executeUpdate();

    }
    public static void addNumName(String name,int num) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Connection connection=getConnection();
        PreparedStatement preparedStatement=getConnection().prepareStatement("update books set num=num+? where name=?");
        preparedStatement.setInt(1,num);
        preparedStatement.setString(2,name);
        preparedStatement.executeUpdate();

    }
    public static ArrayList<Book> personalBook(String id) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        ArrayList<Book> perBooklist=new ArrayList<>();
        Connection connection=getConnection();
        PreparedStatement preparedStatement=getConnection().prepareStatement("select b.id, b.name, b.author, b.genre, b.price from books as b inner join userbooks as ub on b.id=ub.BookId inner join users as u on u.id=ub.userId where u.id=?");
        preparedStatement.setString(1,id);
        ResultSet resultSet =preparedStatement.executeQuery();
        while (resultSet.next()){
            int bookId= resultSet.getInt(1);
            String name=resultSet.getString(2);
            String author= resultSet.getString(3);
            String genre =resultSet.getString(4);
            BigDecimal price=resultSet.getBigDecimal(5);
            Book book=new Book();
            book.setId(bookId);
            book.setName(name);
            book.setAuthor(author);
            book.setGenre(Genre.valueOf(genre));
            book.setPrice(price);
            perBooklist.add(book);
        }

        return perBooklist;
    }
    public static void buyingBook(int userId, String bookId) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Connection connection=getConnection();
        PreparedStatement preparedStatement=getConnection().prepareStatement("insert into userbooks(userId,BookId)  values(?,?)");
        preparedStatement.setInt(1,userId);
        preparedStatement.setString(2,bookId);
        preparedStatement.executeUpdate();
    }
    public static int getUserId(String login, String password) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Connection connection=getConnection();
        PreparedStatement preparedStatement=getConnection().prepareStatement("select id from users where login=? and password=?");
        preparedStatement.setString(1,login);
        preparedStatement.setString(2,password);
        ResultSet resultSet=preparedStatement.executeQuery();
        int id=0;
        while (resultSet.next()){
             id= resultSet.getInt(1);
        }
        return id;
    }
    public static  void deleteBookFromAdmin(String id) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Connection connection=getConnection();
        ArrayList<String> ids=new ArrayList<>();
        PreparedStatement preparedStatement=getConnection().prepareStatement("select ub.userBooksId from userbooks as ub inner join books as b on ub.BookId=b.id where b.id=?");
        preparedStatement.setString(1,id);
        ResultSet resultSet= preparedStatement.executeQuery();
        while (resultSet.next()) {
            id = resultSet.getString(1);
            ids.add(id);
        }
        for (String i :ids) {
        PreparedStatement preparedStatement1=getConnection().prepareStatement("delete from userbooks where userBooksId= ?");
        preparedStatement1.setString(1,i);
        preparedStatement1.executeUpdate();
        }
        PreparedStatement preparedStatement2=getConnection().prepareStatement("delete from books where id=?");
        preparedStatement2.setString(1,id);
        preparedStatement2.executeUpdate();
    }

}
