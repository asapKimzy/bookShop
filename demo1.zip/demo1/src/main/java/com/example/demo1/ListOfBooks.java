package com.example.demo1;

import DataBase.DataBase;
import Model.Book;
import Model.Genre;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Timer;
import java.util.TimerTask;


public class ListOfBooks {
    private ObservableList<Book> booksData = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Book, String> authorColumn;

    @FXML
    private TableColumn<Book, Genre> genreColumn;

    @FXML
    private TableColumn<Book, Integer> idColumn;

    @FXML
    private TableColumn<Book, String> nameColumn;

    @FXML
    private TableColumn<Book, Integer> numColumn;

    @FXML
    private TableColumn<Book, BigDecimal> priceColumn;

    @FXML
    private AnchorPane listOfBooks;
    @FXML
    private Button listOfBooksBuyButton;

    @FXML
    private TextField listOfBooksTextId;
    @FXML
    private Button listOfBooksGoBackButton;
    @FXML
    private Button listOfBooksPersonalButton;

    @FXML
    private TableView<Book> tableBooks;


    public void initialize() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        updateData();
                listOfBooksBuyButton.setOnAction(x->{
                    try {
                        if(DataBase.getId(listOfBooksTextId.getText())){
                            DataBase.deleteBookFromUser(listOfBooksTextId.getText());
                            DataBase.buyingBook(HelloController.id,listOfBooksTextId.getText());
                            updateData();
                        }
                    } catch (SQLException | IllegalAccessException | InstantiationException | ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                });
                listOfBooksGoBackButton.setOnAction(x->{
                    if(HelloController.admin){
                        try {
                            openPage("BookStore.fxml");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        try {
                            openPage("welcomePage.fxml");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                listOfBooksPersonalButton.setOnAction(x->{
                    try {
                        openPage("personalPage.fxml");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
            }


    // подготавливаем данные для таблицы
    // вы можете получать их с базы данных
    private void initData() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        booksData.addAll(DataBase.bookOut());
    }
    public  void openPage(String str) throws IOException {
        listOfBooksGoBackButton.getScene().getWindow().hide();
        FXMLLoader fxmlLoader=new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource(str));
        fxmlLoader.load();
        Parent root=fxmlLoader.getRoot();
        Stage stage=new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    public  void updateData() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        booksData.clear();
        initData();

        // устанавливаем тип и значение которое должно хранится в колонке
        idColumn.setCellValueFactory(new PropertyValueFactory<Book, Integer>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<Book, String>("name"));
        numColumn.setCellValueFactory(new PropertyValueFactory<Book, Integer>("num"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<Book, BigDecimal>("price"));
        authorColumn.setCellValueFactory(new PropertyValueFactory<Book, String>("author"));
        genreColumn.setCellValueFactory(new PropertyValueFactory<Book, Genre>("genre"));

        // заполняем таблицу данными
        tableBooks.setItems(booksData);
    }
}

