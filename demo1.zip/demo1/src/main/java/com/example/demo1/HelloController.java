package com.example.demo1;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ResourceBundle;

import Animation.Animation;
import DataBase.DataBase;
import Model.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class HelloController {
    static Boolean admin=false;
    static User user=new User();
    static int id=0;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField welcomePageLoginField;

    @FXML
    private PasswordField welcomePagePasswordField;

    @FXML
    private Button welcomePageSubmit;
    @FXML
    private Button welcomePageRegistrationButton;

    @FXML
    void initialize() {
        welcomePageSubmit.setOnAction(x->{
          String login = welcomePageLoginField.getText();
          String password = welcomePagePasswordField.getText();

            try {
                if(DataBase.authorisation(login,password)&&DataBase.getRole(login,password).equals("user")){
                   openPage("welcomePage.fxml");
                   admin=false;
                   id=DataBase.getUserId(login,password);
                   //user=
                }
                else if(DataBase.authorisation(login,password)&&DataBase.getRole(login,password).equals("admin")){
                    openPage("bookStore.fxml");
                    admin=true;
                    id=DataBase.getUserId(login,password);
                }
                else{
                    Animation animation=new Animation(welcomePageLoginField);
                    Animation animation1=new Animation(welcomePagePasswordField);
                    animation.start();
                    animation1.start();
                }
            } catch (SQLException | ClassNotFoundException | InstantiationException | IllegalAccessException | IOException e) {
                e.printStackTrace();
            }

        });
        welcomePageRegistrationButton.setOnAction(x->{
            try {
                openPage("registration.fxml");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });


        }

    public  void openPage(String str) throws IOException {
        welcomePageSubmit.getScene().getWindow().hide();
        FXMLLoader fxmlLoader=new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource(str));
        fxmlLoader.load();
        Parent root=fxmlLoader.getRoot();
        Stage stage=new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }


}
