package Model;

public class Cuurency {

}
